package spaceLab_exploration;

public class Main 
{
  protected int focal_length;
  protected int aperture;
  protected double spaceexplorer_age;
  protected double spaceexplorer_weight;
  protected double focal_ratio;
}
